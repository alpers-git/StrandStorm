#pragma once
struct stats
{
    static float avgFrameTime;
    static float lastFrameTime;

    static float avgPhysicsTime;
    static float lastPhysicsTime;

    static float avgRenderTime;
    static float lastRenderTime;
};