#include <Stats.hpp>

float stats::avgFrameTime = 0.0f;
float stats::lastFrameTime = 0.0f;

float stats::avgPhysicsTime = 0.0f;
float stats::lastPhysicsTime = 0.0f;

float stats::avgRenderTime = 0.0f;
float stats::lastRenderTime = 0.0f;