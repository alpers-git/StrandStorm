cout << VectorXi::LinSpaced(Sequential,4,7,10).transpose() << endl;
cout << VectorXd::LinSpaced(Sequential,5,0.0,1.0).transpose() << endl;
